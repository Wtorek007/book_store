package pl.akademiakodu.book_store.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.akademiakodu.book_store.dtos.CategoryDto;
import pl.akademiakodu.book_store.mapper.CategoryMapper;
import pl.akademiakodu.book_store.model.Category;
import pl.akademiakodu.book_store.repository.CategoryRepository;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/")
public class CategoryControllerDto {

    private CategoryRepository categoryRepository;
    private CategoryMapper categoryMapper;

    public CategoryControllerDto(CategoryRepository categoryRepository, CategoryMapper categoryMapper) {
        this.categoryRepository = categoryRepository;
        this.categoryMapper = categoryMapper;
    }

    @GetMapping("categories")
    public ResponseEntity<List<CategoryDto>> getCategories() {

        List<Category> categories = categoryRepository.findAll();
        List<CategoryDto> categoryDtos = new ArrayList<>();

        categories.forEach( b -> categoryDtos.add(categoryMapper.map(b)));
        return new ResponseEntity<>(categoryDtos, HttpStatus.OK);
    }

    
}

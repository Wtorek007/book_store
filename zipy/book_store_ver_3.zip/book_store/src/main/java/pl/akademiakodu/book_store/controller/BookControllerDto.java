package pl.akademiakodu.book_store.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.akademiakodu.book_store.dtos.BookDto;
import pl.akademiakodu.book_store.mapper.BookMapper;
import pl.akademiakodu.book_store.model.Book;
import pl.akademiakodu.book_store.repository.BookRepository;
import pl.akademiakodu.book_store.repository.CategoryRepository;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/")
public class BookControllerDto {

    private BookRepository bookRepository;
    private CategoryRepository categoryRepository;
    private BookMapper mapper;

   // @Autowired
    public BookControllerDto(BookRepository bookRepository, CategoryRepository categoryRepository, BookMapper mapper) {
        this.bookRepository = bookRepository;
        this.categoryRepository = categoryRepository;
        this.mapper = mapper;
    }

    @GetMapping("books")
    public ResponseEntity<List<BookDto>> getBooks() {
      List<Book> books =  bookRepository.findAll();
      List<BookDto> bookDtos = new ArrayList<>();

      //  books.forEach( b -> bookDtos.add(mapper.map(b)));

        for(Book b: books) {
            bookDtos.add(mapper.map(b));
        }

      return new ResponseEntity<>(bookDtos, HttpStatus.OK);
    }


}

package pl.akademiakodu.book_store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import pl.akademiakodu.book_store.model.Book;

import java.util.Optional;

public interface BookRepository extends JpaRepository<Book, Long> {


    String REPORT_BY_ISBN = "select * from books where isbn = ?1";


  // @Query(value = REPORT_BY_ISBN, nativeQuery = true)
  Optional<Book> findByIsbn(String isbn);

}

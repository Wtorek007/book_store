package devlab.app.commons;

public interface Mapper<F,T> {

    T map(F from);


}

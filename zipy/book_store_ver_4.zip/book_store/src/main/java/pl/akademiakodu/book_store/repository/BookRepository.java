package pl.akademiakodu.book_store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import pl.akademiakodu.book_store.model.Book;

import java.util.List;
import java.util.Optional;

public interface BookRepository extends JpaRepository<Book, Long> {


    String BY_ISBN = "select * from books where isbn = ?1";
    String BY_AUTHOR = "select * from books where author like (?1%)";


    // @Query(value = BY_ISBN, nativeQuery = true)
    Optional<Book> findByIsbn(String isbn);

    List<Book> findByCategoryId(Long fk_category);

    @Query(value = BY_AUTHOR, nativeQuery = true)
    Optional<List<Book>> findByAuthors(String author);
}

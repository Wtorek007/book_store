package pl.akademiakodu.book_store.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.akademiakodu.book_store.dtos.CategoryDto;
import pl.akademiakodu.book_store.mapper.CategoryMapper;
import pl.akademiakodu.book_store.model.Category;
import pl.akademiakodu.book_store.repository.CategoryRepository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/")
public class CategoryControllerDto {

    private CategoryRepository categoryRepository;
    private CategoryMapper categoryMapper;

    public CategoryControllerDto(CategoryRepository categoryRepository, CategoryMapper categoryMapper) {
        this.categoryRepository = categoryRepository;
        this.categoryMapper = categoryMapper;
    }

    @GetMapping("categories")
    public ResponseEntity<List<CategoryDto>> getCategories() {

        List<Category> categories = categoryRepository.findAll();
        List<CategoryDto> categoryDtos = new ArrayList<>();

        categories.forEach(b -> categoryDtos.add(categoryMapper.map(b)));
        return new ResponseEntity<>(categoryDtos, HttpStatus.OK);
    }

    @PostMapping("categories")
    public ResponseEntity<Category> addCategory(@RequestBody CategoryDto categoryDto) {
        Optional<Category> categoryOptional = categoryRepository.findByTitle(categoryDto.getTitle());

        if (categoryOptional.isPresent()) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }

        Category category = new Category();

        category.setTitle(categoryDto.getTitle());
        category.setBooks(Collections.emptySet());

        return new ResponseEntity<>(categoryRepository.save(category), HttpStatus.OK);
    }

    @PutMapping("categories")
    public ResponseEntity<Category> updateCategory(@RequestParam String title, @RequestBody CategoryDto category) {
        Optional<Category> categoryOptional = categoryRepository.findByTitle(title);

        if (categoryOptional.isPresent()) {
            categoryOptional.get().setTitle(category.getTitle());
            return new ResponseEntity<>(categoryRepository.save(categoryOptional.get()), HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @DeleteMapping("categories")
    public ResponseEntity<Category> deleteCategory(@RequestParam String category) {
        Optional<Category> categoryOptional = categoryRepository.findByTitle(category);

        if (categoryOptional.isPresent()) {
            categoryRepository.delete(categoryOptional.get());
            return new ResponseEntity<>(HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

}

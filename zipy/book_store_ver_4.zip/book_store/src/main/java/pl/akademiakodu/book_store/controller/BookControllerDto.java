package pl.akademiakodu.book_store.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.akademiakodu.book_store.dtos.BookDto;
import pl.akademiakodu.book_store.mapper.BookMapper;
import pl.akademiakodu.book_store.model.Book;
import pl.akademiakodu.book_store.model.Category;
import pl.akademiakodu.book_store.repository.BookRepository;
import pl.akademiakodu.book_store.repository.CategoryRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("/api/v1/")
public class BookControllerDto {

    private BookRepository bookRepository;
    private CategoryRepository categoryRepository;
    private BookMapper mapper;

    // @Autowired
    public BookControllerDto(BookRepository bookRepository, CategoryRepository categoryRepository, BookMapper mapper) {
        this.bookRepository = bookRepository;
        this.categoryRepository = categoryRepository;
        this.mapper = mapper;
    }

    @GetMapping("books")
    public ResponseEntity<List<BookDto>> getBooks() {
        List<Book> books = bookRepository.findAll();
        List<BookDto> bookDtos = new ArrayList<>();

        //  books.forEach( b -> bookDtos.add(mapper.map(b)));

        for (Book b : books) {
            bookDtos.add(mapper.map(b));
        }
        return new ResponseEntity<>(bookDtos, HttpStatus.OK);
    }

    @GetMapping("books/{isbn}")
    public ResponseEntity<BookDto> getBookByIsbn(@RequestParam(value = "isbn") String isbn) {
        Optional<Book> bookOptional = bookRepository.findByIsbn(isbn);

        if (bookOptional.isPresent()) {
            BookDto bookDto = mapper.map(bookOptional.get());
            return new ResponseEntity<>(bookDto, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }

    @GetMapping("books/{author}")
    public ResponseEntity<List<BookDto>> getBooksByAuthor(@RequestParam(value = "author") String author) {
        Optional<List<Book>> books = bookRepository.findByAuthors(author);
        List<BookDto> bookDtos = new ArrayList<>();

        if (books.isPresent()) {
            books.get().forEach(b -> bookDtos.add(mapper.map(b)));

            return new ResponseEntity<>(bookDtos, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND); /*nie osiagalne*/
    }

    @GetMapping("books/{category}")
    public ResponseEntity<List<BookDto>> getBooksByCategory(@RequestParam(value = "category") String category) {
        Optional<Category> categoryOptional = categoryRepository.findByTitle(category);

        if (categoryOptional.isPresent()) {
            List<Book> books = bookRepository.findByCategoryId(categoryOptional.get().getId());
            List<BookDto> bookDtos = new ArrayList<>();

            books.forEach(book -> {
                BookDto bookDto = mapper.map(book);
                bookDtos.add(bookDto);
            });

            return new ResponseEntity<>(bookDtos, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }




}

package pl.akademiakodu.book_store.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.akademiakodu.book_store.model.Book;
import pl.akademiakodu.book_store.repository.BookRepository;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/")
public class BookController {


    private BookRepository bookRepository;

   // @Autowired /*nie jest wymagane*/
    public BookController(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @GetMapping("books")
    public ResponseEntity<List<Book>> getBooks() {
        return new ResponseEntity<>(bookRepository.findAll(), HttpStatus.OK);
    }
    
}

package pl.akademiakodu.book_store.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pl.akademiakodu.book_store.model.Book;

public interface BookRepository extends JpaRepository<Book, Long> {

}
